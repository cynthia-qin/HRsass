import { getToken, setToken, removeToken } from '@/utils/auth'
const state = {
  // 设置token初始化状态
  token: getToken()
}
// ca'z
const mutations = {
  // 保存token到本地存储
  setToken (state, token) {
    state.token = token
    setToken(token)
  },
  // 删除token
  removeToken (state) {
    state.token = null
    removeToken()
  }
}
const actions = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
